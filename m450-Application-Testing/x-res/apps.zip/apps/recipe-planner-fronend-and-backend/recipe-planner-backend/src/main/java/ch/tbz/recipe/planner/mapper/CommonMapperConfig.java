package ch.tbz.recipe.planner.mapper;

import org.mapstruct.InjectionStrategy;
import org.mapstruct.MapperConfig;
import org.mapstruct.ReportingPolicy;

@MapperConfig(componentModel = "spring"
)
public class CommonMapperConfig {
}
