package ch.tbz.recipe.planner.domain;

public enum Unit {
    PIECE,
    GRAMM,
    KILOGRAMM,
    LITRE,
    DECILITRE

}
