#!/bin/sh

cd ./Testcases

../vendor/bin/phpunit Test.php

echo "Test run complete."
